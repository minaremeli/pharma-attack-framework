# Copyright (c) 2020 KU Leuven
__version__ = "0.7.2"
